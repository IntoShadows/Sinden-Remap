﻿#NoEnv  ; Recommended for performance and compatibility with future AutoHotkey releases.
; #Warn  ; Enable warnings to assist with detecting common errors.
SendMode Input  ; Recommended for new scripts due to its superior speed and reliability.
SetWorkingDir %A_ScriptDir%  ; Ensures a consistent starting directory.
#SingleInstance force


FileDelete, %A_Scriptdir%\list.txt
FileDelete, %A_Scriptdir%\retroarch.cfg.temp
ToolTip, Initializing Sinden Remap, mouseX, mouseY
iniread, P1pid, sindenremap.ini, general, P1pid, 1
iniread, P2pid, sindenremap.ini, general, P2pid, 2
iniread, P1name, sindenremap.ini, general, P1name, 0
iniread, P2name, sindenremap.ini, general, P2name, 0
iniread, guns, sindenremap.ini, general, guns, 0

tooltip

if (guns>0)
	gosub emuconfig

start:
MsgBox, 49, Sinden ID Remap utility configuration, This tool wil configure your lightgun indexes for Retroarch and Supermodel.`n`nUnplug your Sinden Lightgun(s) to and press OK to begin

Ifmsgbox, Cancel
	ExitApp
ifmsgbox, OK
	gosub checkgun1

checkgun1:
sleep 300
ToolTip, Reading device IDs, mouseX, mouseY
Run %comspec% /c `"%A_Scriptdir%\ControllerRemap.exe`" /list > list.txt ,, hide
sleep 500

ID = 0
numID = 0
guns = 0

ToolTip, Identifying Lightguns, mouseX, mouseY
Loop, read, %A_ScriptDir%\list.txt  , %A_scriptdir%\IDs.txt
{ 
ID := SubStr(A_LoopReadLine, 4 , 1)
if (ID > 0 AND ID < 20 )
{
	If InStr(A_LoopReadLine, "VID_16C0_PID_0F01") or InStr(A_LoopReadLine, "VID_16C0_PID_0F02") or InStr(A_LoopReadLine, "VID_16C0_PID_0F38") or InStr(A_LoopReadLine, "VID_16C0_PID_0F39")
		guns += 1
	}
tooltip
If (guns>0)
{
	MsgBox, 17, Sinden ID Remap utility configuration, Gun(s) still connected. Disconnect your gun(s) and press OK
	gosub checkgun1
}

}
; detect player 1 gun----------------------------------------------------------------------------------------
noguns:
FileDelete, %A_Scriptdir%\list.txt
MsgBox, 65, Sinden ID Remap utility configuration, Connect your Player 1 lightgun now.`n`nWait until it's detected by Windows (You will hear the USB connection sound) and press OK.
IfMsgBox, cancel
	ExitApp
sleep 1000
ToolTip, Reading device IDs, mouseX, mouseY
Run %comspec% /c `"%A_Scriptdir%\ControllerRemap.exe`" /list > list.txt ,, hide

sleep 500

ID = 0
numID = 0
guns = 0

ToolTip, Identifying Player 1 Lightgun, mouseX, mouseY
Loop, read, %A_ScriptDir%\list.txt  , %A_scriptdir%\IDs.txt
{ 
ID := SubStr(A_LoopReadLine, 4 , 1)
if (ID > 0 AND ID < 20 )
{
	If InStr(A_LoopReadLine, "VID_16C0_PID_0F01")
	{
		P1pid = %ID%
		P1name = F01
		guns += 1
		break
	}
	If InStr(A_LoopReadLine, "VID_16C0_PID_0F02")
	{
		P1pid = %ID%
		P1name = F02
		guns += 1
		break
	}
	If InStr(A_LoopReadLine, "VID_16C0_PID_0F38")
	{
		P1pid = %ID%
		P1name = F38
		guns += 1
		break
	}
	If InStr(A_LoopReadLine, "VID_16C0_PID_0F39")
	{
		P1pid = %ID%
		P1name = F39
		guns += 1
		break
	}
numID+=1	
}
}

if (guns=0)
	gosub noguns
ToolTip

; detect player 2 gun----------------------------------------------------------------------------------------

MsgBox, 36, Sinden ID Remap utility configuration, Lightgun1 (%P1name%) detected with index %P1pid%`nDo you have 2 lightguns?

IfMsgBox, Yes
{ 
	gosub detectp2gun
}
else
{
	P2pid=nul
	gosub saveini
}

detectp2gun:
FileDelete, %A_Scriptdir%\list.txt
MsgBox, 65, Sinden ID Remap utility configuration, Connect your Player 2 lightgun now.`n`nWait until it's detected by Windows (You will hear the USB connection sound) and press OK.
IfMsgBox, cancel
	ExitApp
sleep 1000
ToolTip, Reading device IDs, mouseX, mouseY
Run %comspec% /c `"%A_Scriptdir%\ControllerRemap.exe`" /list > list.txt ,, hide

sleep 500

ID = 0

ToolTip, Identifying Player 2 Lightgun, mouseX, mouseY
Loop, read, %A_ScriptDir%\list.txt  , %A_scriptdir%\IDs.txt
{ 
ID2 := SubStr(A_LoopReadLine, 4 , 1)
if (ID2 > 0 AND ID2 < 20 )
{
	If InStr(A_LoopReadLine, "VID_16C0_PID_0F01")
	{
		if (ID2 != P1pid)
		{
			P2pid = %ID2%
			P2name = F01
			break
		}
	}
	If InStr(A_LoopReadLine, "VID_16C0_PID_0F02")
	{
		
		if (ID2 != P1pid)
		{
			P2pid = %ID2%
			P2name = F02
			break
		}
	}
	If InStr(A_LoopReadLine, "VID_16C0_PID_0F38")
	{
		if (ID2 != P1pid)
		{
			P2pid = %ID2%
			P2name = F38
			break
		}
	}
	If InStr(A_LoopReadLine, "VID_16C0_PID_0F39")
	{
		if (ID2 != P1pid)
		{
			P2pid = %ID2%
			P2name = F39
			break
		}
	}
}
if (P2name!=0)
	break
}

if (P2name=0)
	gosub detectp2gun

guns+=1
ToolTip
gosub saveini

saveini:
change = 0
sleep 500
IniWrite, %p2pid%, sindenremap.ini, general, P2pid
iniwrite, %guns%, sindenremap.ini, general, guns
IniWrite, %P1pid%, sindenremap.ini, general, P1pid
Iniwrite, %P1name%, sindenremap.ini, general, P1name
Iniwrite, %P2name%, sindenremap.ini, general, P2name

emuconfig:

Tooltip, Number of guns: %guns%`nPlayer 1 %P1name%: %P1pid% `nPlayer 2 %P1name%: %P2pid%
sleep 1000


;check if PID have changed--------------------------------------------------------------------------------
ToolTip, Checking if indexes have changed, mouseX, mouseY
Run %comspec% /c `"%A_Scriptdir%\ControllerRemap.exe`" /list > list.txt ,, hide
sleep 500
currentguns = 0
newP1pid = %P1pid%
newP2pid = %P2pid%
numID = 0
Loop, read, %A_ScriptDir%\list.txt  , %A_scriptdir%\IDs.txt
{ 
IDC := SubStr(A_LoopReadLine, 4 , 1)
if (IDC > 0 AND IDC < 20 )
{
	If InStr(A_LoopReadLine, P1name)
	{
		if (IDC != P1pid)
		{
			tooltip, Lightgun 1 Index changed. Adjusting new index
			newP1pid = %IDC%
			
			change = 1
		}
		currentguns += 1
	}
	If InStr(A_LoopReadLine, P2name)
	{
		if (IDC != P2pid)
		{
			tooltip, Lightgun 1 Index changed. Adjusting new index
			newP2pid = %IDC%
			change = 1
			
		}
		currentguns += 1
	}
	numID +=1
}
}

if (guns!=currentguns)
{
	MsgBox, 53, Sinden ID Remap utility configuration, One or both lightguns can't be found.`n(Re)Connect your guns and click Retry or press Cancel to run the configuration tool.
	ifmsgbox, Retry
		gosub emuconfig
	ifmsgbox, Cancel
		gosub start
}

if (change=1)
{
	P1pid = %newP1pid%
	P2pid = %newP2pid%
	gosub saveini
}
tooltip

ToolTip, Finding emulator, mouseX, mouseY
; Retroarch config----------------------------------------------------------------------------------------

if FileExist(A_scriptDir "\retroarch.exe")
{
	P1pid := numID - P1pid
	if (guns > 1)
		P2pid := numID - P2pid
	else
		P2pid = nul
ToolTip, Editing Retroarch.cfg, mouseX, mouseY
Loop, read, retroarch.cfg  , retroarch.cfg.temp
{
	If InStr(A_LoopReadLine, "input_player1_mouse_index")
	{
		Fileappend, input_player1_mouse_index = `"%P1pid%`"`n, retroarch.cfg.temp
	}
	else if InStr(A_LoopReadLine, "input_player2_mouse_index")
	{
		Fileappend, input_player2_mouse_index = `"%P2pid%`"`n, retroarch.cfg.temp
	}
	else
	{
		FileAppend, %A_LoopReadLine%`n, retroarch.cfg.temp
	}
}
sleep 500
FileMove, retroarch.cfg, retroarch.cfg.bak, 1
sleep 500
Filemove, retroarch.cfg.temp, retroarch.cfg, 1
sleep 2000
}

; Supermodel config----------------------------------------------------------------------------------------
ToolTip, Editing Supermodel.ini, mouseX, mouseY
if FileExist(A_scriptDir "\supermodel.exe")
{
	;Write changes to supermodel.ini
	;Player1 GUN
	iniwrite, %a_Space%`"MOUSE%P1pid%_XAXIS`,JOY1_XAXIS`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputGunX  
	iniwrite, %a_Space%`"MOUSE%P1pid%_YAXIS`,JOY1_YAXIS`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputGunY 
	iniwrite, %a_Space%`"KEY_A`,JOY1_BUTTON1`,MOUSE%P1pid%_LEFT_BUTTON`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputTrigger
	iniwrite, %a_Space%`"KEY_S`,JOY1_BUTTON2`,MOUSE%P1pid%_RIGHT_BUTTON`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputOffscreen
	
	;Player1 ANALOG GUN
	iniwrite, %a_Space%`"MOUSE%P1pid%_XAXIS`,JOY1_XAXIS`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputAnalogGunX  
	iniwrite, %a_Space%`"MOUSE%P1pid%_YAXIS`,JOY1_YAXIS`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputAnalogGunY 
	iniwrite, %a_Space%`"KEY_A`,JOY1_BUTTON1`,MOUSE%P1pid%_LEFT_BUTTON`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputAnalogTriggerLeft
	iniwrite, %a_Space%`"KEY_S`,JOY1_BUTTON2`,MOUSE%P1pid%_RIGHT_BUTTON`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputAnalogTriggerRight
	
	;Player1 ANALOG JOYSTICK
	iniwrite, %a_Space%`"MOUSE%P1pid%_XAXIS`,JOY1_XAXIS`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputAnalogJoyX  
	iniwrite, %a_Space%`"MOUSE%P1pid%_YAXIS`,JOY1_YAXIS`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputAnalogJoyY 

	
	if (guns>1)
	{
	;Player2 GUN
	iniwrite, %a_Space%`"MOUSE%P2pid%_XAXIS`,JOY2_XAXIS`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputGunX2
	iniwrite, %a_Space%`"MOUSE%P2pid%_YAXIS`,JOY2_YAXIS`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputGunY2
	iniwrite, %a_Space%`"KEY_Z`,JOY2_BUTTON1`,MOUSE%P2pid%_LEFT_BUTTON`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputTrigger2
	iniwrite, %a_Space%`"KEY_X`,JOY2_BUTTON2`,MOUSE%P2pid%_RIGHT_BUTTON`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputOffscreen2

	;Player2 ANALOG GUN
	iniwrite, %a_Space%`"MOUSE%P2pid%_XAXIS`,JOY2_XAXIS`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputAnalogGunX2
	iniwrite, %a_Space%`"MOUSE%P2pid%_YAXIS`,JOY2_YAXIS`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputAnalogGunY2
	iniwrite, %a_Space%`"KEY_Z`,JOY2_BUTTON1`,MOUSE%P2pid%_LEFT_BUTTON`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputAnalogTriggerLeft2
	iniwrite, %a_Space%`"KEY_X`,JOY2_BUTTON2`,MOUSE%P2pid%_RIGHT_BUTTON`" , %A_ScriptDir%\Config\Supermodel.ini, global, InputAnalogTriggerRight2

	}
}

ToolTip, Closing, mouseX, mouseY
Sleep 2000
ToolTip
ExitApp


ToolTip
ExitApp

