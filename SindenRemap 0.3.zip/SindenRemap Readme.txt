Place both AHK-or-EXE and ControllerRemap.exe into SUPERMODEL or RETROARCH main folder.

SindenRemap:
The script will ask to disconnect both guns and connect them in order. Then will config Retroarch or Supermodel.

After the initial run, everytime it runs will check for changes in the indexes and correct, without prompt. If a gun is missing it will give the option either to reconnect and retry or restart configuration.

To force-restart the configuration delete the Sindenremap.ini file and restart the app.

